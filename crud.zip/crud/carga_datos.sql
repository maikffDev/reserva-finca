-- ===============================
-- CARGA DE DATOS DE PRUEBA
-- ===============================

-- 1. Rol
INSERT INTO Rol (nombreRol) VALUES
('Administrador'),
('Cliente');

-- 2. Usuario
INSERT INTO Usuario (Nombre, Correo, Contraseña, IntentosFallidosIngreso, Activo, Rol_Id) VALUES
('Juan Pérez', 'juan@example.com', '1234', 0, TRUE, 1),
('Ana Gómez', 'ana@example.com', 'abcd', 1, TRUE, 2);

-- 3. Amenitie
INSERT INTO Amenitie (Nombre, TipoDeAmenitie) VALUES
('Piscina', 'Recreación'),
('WiFi', 'Servicios'),
('Zona BBQ', 'Recreación');

-- 4. FINCA
INSERT INTO FINCA (Nombre, Ubicacion, TarifaHora, UsuarioId, Descripcion, Activo) VALUES
('Finca El Bosque', 'Valle del Cauca', 100.00, 1, 'Una finca con mucho verde', TRUE),
('Finca El Lago', 'Antioquia', 120.00, 1, 'Ideal para descansar junto al lago', TRUE);

-- 5. Amenitie_FINCA
INSERT INTO Amenitie_FINCA (FincaID, AmenitieID) VALUES
(1, 1),
(1, 2),
(2, 3);

-- 6. Imagen
INSERT INTO Imagen (FincaID, urlImagen) VALUES
(1, 'https://ejemplo.com/imagen1.jpg'),
(2, 'https://ejemplo.com/imagen2.jpg');

-- 7. Horario
INSERT INTO Horario (HoraInicio, HoraFin, Fecha) VALUES
('08:00', '18:00', '2025-07-01'),
('10:00', '17:00', '2025-07-02');

-- 8. Finca_Horario
INSERT INTO Finca_Horario (HorarioID, FincaID) VALUES
(1, 1),
(2, 2);

-- 9. Descuento
INSERT INTO Descuento (Nombre, DescuentoPorcentaje) VALUES
('Temporada Baja', 10.00),
('Cliente Frecuente', 15.00);

-- 10. Temporada
INSERT INTO Temporada (temporadaNombre) VALUES
('Verano'),
('Invierno');

-- 11. TipoDeTemporada
INSERT INTO TipoDeTemporada (IdTemporada, idDescuento) VALUES
(1, 1),
(2, 2);

-- 12. Reserva
INSERT INTO Reserva (FincaHorarioID, UsuarioID, TipoDeTemporada, Activo, Vencimiento) VALUES
(1, 2, 1, TRUE, '2025-06-30'),
(2, 2, 2, TRUE, '2025-07-01');

-- 13. Comentario
INSERT INTO Comentario (UsuarioId, FincaID, ReservId, Descripcion) VALUES
(2, 1, 1, 'Muy buena finca, excelente atención'),
(2, 2, 2, 'Buen lugar pero algo alejado');

-- 14. MetodoDePago
INSERT INTO MetodoDePago (Tipo) VALUES
('Tarjeta de Crédito'),
('Transferencia Bancaria');

-- 15. Ticket
INSERT INTO Ticket (ReservID, CostoTotal, MetodoDePago, Estado, FechaDePago) VALUES
(1, 900.00, 1, 'Pagado', '2025-06-01'),
(2, 840.00, 2, 'Pendiente', '2025-06-05');
