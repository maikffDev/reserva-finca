--------------------------------------------------------------------------------
-- CRUD PARA ROL
--------------------------------------------------------------------------------
-- CREATE Rol
CREATE OR REPLACE PROCEDURE crear_rol(
    p_nombrerol VARCHAR(100)
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO rol (nombrerol)
    VALUES (p_nombrerol);
END;
$$;

-- READ Rol
CREATE OR REPLACE FUNCTION obtener_rol(p_rol_id INT)
RETURNS TABLE (
    rol_id INT,
    nombrerol VARCHAR(100)
) AS $$
BEGIN
    RETURN QUERY
       SELECT R.rol_id AS rol_id,
              R.nombrerol AS nombrerol
       FROM rol R
       WHERE R.rol_id = p_rol_id;
END;
$$ LANGUAGE plpgsql;

-- UPDATE Rol
CREATE OR REPLACE PROCEDURE actualizar_rol(
    p_rol_id INT,
    p_nombrerol VARCHAR(100)
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE rol
    SET nombrerol = p_nombrerol
    WHERE rol_id = p_rol_id;
END;
$$;

-- DELETE Rol
CREATE OR REPLACE PROCEDURE eliminar_rol(
    p_rol_id INT
)
LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM rol
    WHERE rol_id = p_rol_id;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA USUARIO
--------------------------------------------------------------------------------
-- CREATE Usuario
CREATE OR REPLACE PROCEDURE crear_usuario(
    p_nombre VARCHAR(100),
    p_correo VARCHAR(100),
    p_contrasena VARCHAR(100),
    p_rol_id INT
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO usuario (nombre, correo, contraseña, intentosfallidosingreso, activo, rol_id)
    VALUES (p_nombre, p_correo, p_contrasena, 0, TRUE, p_rol_id);
END;
$$;

-- READ Usuario
CREATE OR REPLACE FUNCTION obtener_usuario(p_usuarioid INT)
RETURNS TABLE (
    usuarioid INT,
    nombre VARCHAR(100),
    correo VARCHAR(100),
    rol_id INT,
    activo BOOLEAN
) AS $$
BEGIN
    RETURN QUERY
       SELECT U.usuarioid AS usuarioid,
              U.nombre AS nombre,
              U.correo AS correo,
              U.rol_id AS rol_id,
              U.activo AS activo
       FROM usuario U
       WHERE U.usuarioid = p_usuarioid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE Usuario
CREATE OR REPLACE PROCEDURE actualizar_usuario(
    p_usuarioid INT,
    p_nombre VARCHAR(100),
    p_correo VARCHAR(100),
    p_contrasena VARCHAR(100),
    p_rol_id INT,
    p_activo BOOLEAN
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE usuario
    SET nombre = p_nombre,
        correo = p_correo,
        contraseña = p_contrasena,
        rol_id = p_rol_id,
        activo = p_activo
    WHERE usuarioid = p_usuarioid;
END;
$$;

-- DELETE Usuario (marcar inactivo)
CREATE OR REPLACE PROCEDURE eliminar_usuario(
    p_usuarioid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE usuario
    SET activo = FALSE
    WHERE usuarioid = p_usuarioid;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA AMENITIE
--------------------------------------------------------------------------------
-- CREATE Amenitie
CREATE OR REPLACE PROCEDURE crear_amenitie(
    p_nombre VARCHAR(100),
    p_tipodeamenitie VARCHAR(100)
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO amenitie (nombre, tipodeamenitie)
    VALUES (p_nombre, p_tipodeamenitie);
END;
$$;

-- READ Amenitie
CREATE OR REPLACE FUNCTION obtener_amenitie(p_amenitieid INT)
RETURNS TABLE (
    amenitieid INT,
    nombre VARCHAR(100),
    tipodeamenitie VARCHAR(100)
) AS $$
BEGIN
    RETURN QUERY
       SELECT A.amenitieid AS amenitieid,
              A.nombre AS nombre,
              A.tipodeamenitie AS tipodeamenitie
       FROM amenitie A
       WHERE A.amenitieid = p_amenitieid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE Amenitie
CREATE OR REPLACE PROCEDURE actualizar_amenitie(
    p_amenitieid INT,
    p_nombre VARCHAR(100),
    p_tipodeamenitie VARCHAR(100)
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE amenitie
    SET nombre = p_nombre,
        tipodeamenitie = p_tipodeamenitie
    WHERE amenitieid = p_amenitieid;
END;
$$;

-- DELETE Amenitie
CREATE OR REPLACE PROCEDURE eliminar_amenitie(
    p_amenitieid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM amenitie
    WHERE amenitieid = p_amenitieid;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA AMENITIE_FINCA
--------------------------------------------------------------------------------
-- CREATE Amenitie_FINCA
CREATE OR REPLACE PROCEDURE crear_amenitie_finca(
    p_fincaid INT,
    p_amenitieid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO amenitie_finca (fincaid, amenitieid)
    VALUES (p_fincaid, p_amenitieid);
END;
$$;

-- READ Amenitie_FINCA
CREATE OR REPLACE FUNCTION obtener_amenitie_finca(
    p_fincaid INT,
    p_amenitieid INT
)
RETURNS TABLE (
    fincaid INT,
    amenitieid INT
) AS $$
BEGIN
    RETURN QUERY
       SELECT AF.fincaid AS fincaid,
              AF.amenitieid AS amenitieid
       FROM amenitie_finca AF
       WHERE AF.fincaid = p_fincaid AND AF.amenitieid = p_amenitieid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE Amenitie_FINCA (No es habitual actualizar una relación N:M)
CREATE OR REPLACE PROCEDURE actualizar_amenitie_finca(
    p_fincaid INT,
    p_amenitieid INT,
    p_nuevafincaid INT,
    p_nuevoamenitieid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE amenitie_finca
    SET fincaid = p_nuevafincaid,
        amenitieid = p_nuevoamenitieid
    WHERE fincaid = p_fincaid AND amenitieid = p_amenitieid;
END;
$$;

-- DELETE Amenitie_FINCA
CREATE OR REPLACE PROCEDURE eliminar_amenitie_finca(
    p_fincaid INT,
    p_amenitieid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM amenitie_finca
    WHERE fincaid = p_fincaid AND amenitieid = p_amenitieid;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA IMAGEN
--------------------------------------------------------------------------------
-- CREATE Imagen
CREATE OR REPLACE PROCEDURE crear_imagen(
    p_fincaid INT,
    p_urlimagen TEXT
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO imagen (fincaid, urlimagen)
    VALUES (p_fincaid, p_urlimagen);
END;
$$;

-- READ Imagen
CREATE OR REPLACE FUNCTION obtener_imagen(p_imagenid INT)
RETURNS TABLE (
    imagenid INT,
    fincaid INT,
    urlimagen TEXT
) AS $$
BEGIN
    RETURN QUERY
       SELECT I.imagenid AS imagenid,
              I.fincaid AS fincaid,
              I.urlimagen AS urlimagen
       FROM imagen I
       WHERE I.imagenid = p_imagenid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE Imagen
CREATE OR REPLACE PROCEDURE actualizar_imagen(
    p_imagenid INT,
    p_fincaid INT,
    p_urlimagen TEXT
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE imagen
    SET fincaid = p_fincaid,
        urlimagen = p_urlimagen
    WHERE imagenid = p_imagenid;
END;
$$;

-- DELETE Imagen
CREATE OR REPLACE PROCEDURE eliminar_imagen(
    p_imagenid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM imagen
    WHERE imagenid = p_imagenid;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA HORARIO
--------------------------------------------------------------------------------
-- CREATE Horario
CREATE OR REPLACE PROCEDURE crear_horario(
    p_horainicio TIME,
    p_horafin TIME,
    p_fecha DATE
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO horario (horainicio, horafin, fecha)
    VALUES (p_horainicio, p_horafin, p_fecha);
END;
$$;

-- READ Horario
CREATE OR REPLACE FUNCTION obtener_horario(p_horarioid INT)
RETURNS TABLE (
    horarioid INT,
    horainicio TIME,
    horafin TIME,
    fecha DATE
) AS $$
BEGIN
    RETURN QUERY
       SELECT H.horarioid AS horarioid,
              H.horainicio AS horainicio,
              H.horafin AS horafin,
              H.fecha AS fecha
       FROM horario H
       WHERE H.horarioid = p_horarioid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE Horario
CREATE OR REPLACE PROCEDURE actualizar_horario(
    p_horarioid INT,
    p_horainicio TIME,
    p_horafin TIME,
    p_fecha DATE
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE horario
    SET horainicio = p_horainicio,
        horafin = p_horafin,
        fecha = p_fecha
    WHERE horarioid = p_horarioid;
END;
$$;

-- DELETE Horario
CREATE OR REPLACE PROCEDURE eliminar_horario(
    p_horarioid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM horario
    WHERE horarioid = p_horarioid;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA FINCA_HORARIO
--------------------------------------------------------------------------------
-- CREATE Finca_Horario
CREATE OR REPLACE PROCEDURE crear_finca_horario(
    p_horarioid INT,
    p_fincaid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO finca_horario (horarioid, fincaid)
    VALUES (p_horarioid, p_fincaid);
END;
$$;

-- READ Finca_Horario
CREATE OR REPLACE FUNCTION obtener_finca_horario(p_fincahorarioid INT)
RETURNS TABLE (
    fincahorarioid INT,
    horarioid INT,
    fincaid INT
) AS $$
BEGIN
    RETURN QUERY
       SELECT FH.fincahorarioid AS fincahorarioid,
              FH.horarioid AS horarioid,
              FH.fincaid AS fincaid
       FROM finca_horario FH
       WHERE FH.fincahorarioid = p_fincahorarioid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE Finca_Horario
CREATE OR REPLACE PROCEDURE actualizar_finca_horario(
    p_fincahorarioid INT,
    p_horarioid INT,
    p_fincaid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE finca_horario
    SET horarioid = p_horarioid,
        fincaid = p_fincaid
    WHERE fincahorarioid = p_fincahorarioid;
END;
$$;

-- DELETE Finca_Horario
CREATE OR REPLACE PROCEDURE eliminar_finca_horario(
    p_fincahorarioid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM finca_horario
    WHERE fincahorarioid = p_fincahorarioid;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA DESCUENTO
--------------------------------------------------------------------------------
-- CREATE Descuento
CREATE OR REPLACE PROCEDURE crear_descuento(
    p_nombre VARCHAR(100),
    p_descuentoporcentaje NUMERIC(5,2)
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO descuento (nombre, descuentoporcentaje)
    VALUES (p_nombre, p_descuentoporcentaje);
END;
$$;

-- READ Descuento
CREATE OR REPLACE FUNCTION obtener_descuento(p_descuentoid INT)
RETURNS TABLE (
    descuentoid INT,
    nombre VARCHAR(100),
    descuentoporcentaje NUMERIC(5,2)
) AS $$
BEGIN
    RETURN QUERY
       SELECT D.descuentoid AS descuentoid,
              D.nombre AS nombre,
              D.descuentoporcentaje AS descuentoporcentaje
       FROM descuento D
       WHERE D.descuentoid = p_descuentoid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE Descuento
CREATE OR REPLACE PROCEDURE actualizar_descuento(
    p_descuentoid INT,
    p_nombre VARCHAR(100),
    p_descuentoporcentaje NUMERIC(5,2)
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE descuento
    SET nombre = p_nombre,
        descuentoporcentaje = p_descuentoporcentaje
    WHERE descuentoid = p_descuentoid;
END;
$$;

-- DELETE Descuento
CREATE OR REPLACE PROCEDURE eliminar_descuento(
    p_descuentoid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM descuento
    WHERE descuentoid = p_descuentoid;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA TEMPORADA
--------------------------------------------------------------------------------
-- CREATE Temporada
CREATE OR REPLACE PROCEDURE crear_temporada(
    p_temporadanombre VARCHAR(100)
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO temporada (temporadanombre)
    VALUES (p_temporadanombre);
END;
$$;

-- READ Temporada
CREATE OR REPLACE FUNCTION obtener_temporada(p_temporadaid INT)
RETURNS TABLE (
    temporadaid INT,
    temporadanombre VARCHAR(100)
) AS $$
BEGIN
    RETURN QUERY
       SELECT T.temporadaid AS temporadaid,
              T.temporadanombre AS temporadanombre
       FROM temporada T
       WHERE T.temporadaid = p_temporadaid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE Temporada
CREATE OR REPLACE PROCEDURE actualizar_temporada(
    p_temporadaid INT,
    p_temporadanombre VARCHAR(100)
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE temporada
    SET temporadanombre = p_temporadanombre
    WHERE temporadaid = p_temporadaid;
END;
$$;

-- DELETE Temporada
CREATE OR REPLACE PROCEDURE eliminar_temporada(
    p_temporadaid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM temporada
    WHERE temporadaid = p_temporadaid;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA TIPODETEMPORADA
--------------------------------------------------------------------------------
-- CREATE TipoDeTemporada
CREATE OR REPLACE PROCEDURE crear_tipodetemporada(
    p_idtemporada INT,
    p_iddescuento INT
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO tipodetemporada (idtemporada, iddescuento)
    VALUES (p_idtemporada, p_iddescuento);
END;
$$;

-- READ TipoDeTemporada
CREATE OR REPLACE FUNCTION obtener_tipodetemporada(p_idtipodetemporada INT)
RETURNS TABLE (
    idtipodetemporada INT,
    idtemporada INT,
    iddescuento INT
) AS $$
BEGIN
    RETURN QUERY
       SELECT TT.idtipodetemporada AS idtipodetemporada,
              TT.idtemporada AS idtemporada,
              TT.iddescuento AS iddescuento
       FROM tipodetemporada TT
       WHERE TT.idtipodetemporada = p_idtipodetemporada;
END;
$$ LANGUAGE plpgsql;

-- UPDATE TipoDeTemporada
CREATE OR REPLACE PROCEDURE actualizar_tipodetemporada(
    p_idtipodetemporada INT,
    p_idtemporada INT,
    p_iddescuento INT
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE tipodetemporada
    SET idtemporada = p_idtemporada,
        iddescuento = p_iddescuento
    WHERE idtipodetemporada = p_idtipodetemporada;
END;
$$;

-- DELETE TipoDeTemporada
CREATE OR REPLACE PROCEDURE eliminar_tipodetemporada(
    p_idtipodetemporada INT
)
LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM tipodetemporada
    WHERE idtipodetemporada = p_idtipodetemporada;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA RESERVA
--------------------------------------------------------------------------------
-- (Se incluye nuevamente para completitud)
-- CREATE Reserva
CREATE OR REPLACE PROCEDURE crear_reserva(
    p_fincahorarioid INT,
    p_usuarioid INT,
    p_tipodetemporada INT,
    p_vencimiento DATE
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO reserva (fincahorarioid, usuarioid, tipodetemporada, activo, vencimiento)
    VALUES (p_fincahorarioid, p_usuarioid, p_tipodetemporada, TRUE, p_vencimiento);
END;
$$;

-- READ Reserva
CREATE OR REPLACE FUNCTION obtener_reserva(p_reservid INT)
RETURNS TABLE (
    reservid INT,
    fincahorarioid INT,
    usuarioid INT,
    tipodetemporada INT,
    activo BOOLEAN,
    vencimiento DATE
) AS $$
BEGIN
    RETURN QUERY
       SELECT R.reservid AS reservid,
              R.fincahorarioid AS fincahorarioid,
              R.usuarioid AS usuarioid,
              R.tipodetemporada AS tipodetemporada,
              R.activo AS activo,
              R.vencimiento AS vencimiento
       FROM reserva R
       WHERE R.reservid = p_reservid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE Reserva
CREATE OR REPLACE PROCEDURE actualizar_reserva(
    p_reservid INT,
    p_fincahorarioid INT,
    p_usuarioid INT,
    p_tipodetemporada INT,
    p_vencimiento DATE,
    p_activo BOOLEAN
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE reserva
    SET fincahorarioid = p_fincahorarioid,
        usuarioid = p_usuarioid,
        tipodetemporada = p_tipodetemporada,
        vencimiento = p_vencimiento,
        activo = p_activo
    WHERE reservid = p_reservid;
END;
$$;

-- DELETE Reserva (marcar inactivo)
CREATE OR REPLACE PROCEDURE eliminar_reserva(
    p_reservid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE reserva
    SET activo = FALSE
    WHERE reservid = p_reservid;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA COMENTARIO
--------------------------------------------------------------------------------
-- CREATE Comentario
CREATE OR REPLACE PROCEDURE crear_comentario(
    p_usuarioid INT,
    p_fincaid INT,
    p_reservid INT,
    p_descripcion TEXT
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO comentario (usuarioid, fincaid, reservid, descripcion)
    VALUES (p_usuarioid, p_fincaid, p_reservid, p_descripcion);
END;
$$;

-- READ Comentario
CREATE OR REPLACE FUNCTION obtener_comentario(
    p_usuarioid INT,
    p_fincaid INT,
    p_reservid INT
)
RETURNS TABLE (
    usuarioid INT,
    fincaid INT,
    reservid INT,
    descripcion TEXT
) AS $$
BEGIN
    RETURN QUERY
       SELECT C.usuarioid AS usuarioid,
              C.fincaid AS fincaid,
              C.reservid AS reservid,
              C.descripcion AS descripcion
       FROM comentario C
       WHERE C.usuarioid = p_usuarioid
         AND C.fincaid = p_fincaid
         AND C.reservid = p_reservid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE Comentario
CREATE OR REPLACE PROCEDURE actualizar_comentario(
    p_usuarioid INT,
    p_fincaid INT,
    p_reservid INT,
    p_descripcion TEXT
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE comentario
    SET descripcion = p_descripcion
    WHERE usuarioid = p_usuarioid
      AND fincaid = p_fincaid
      AND reservid = p_reservid;
END;
$$;

-- DELETE Comentario
CREATE OR REPLACE PROCEDURE eliminar_comentario(
    p_usuarioid INT,
    p_fincaid INT,
    p_reservid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM comentario
    WHERE usuarioid = p_usuarioid
      AND fincaid = p_fincaid
      AND reservid = p_reservid;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA METODODEPAGO
--------------------------------------------------------------------------------
-- CREATE MetodoDePago
CREATE OR REPLACE PROCEDURE crear_metodopago(
    p_tipo VARCHAR(50)
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO metodopago (tipo)
    VALUES (p_tipo);
END;
$$;

-- READ MetodoDePago
CREATE OR REPLACE FUNCTION obtener_metodopago(p_metodopagoid INT)
RETURNS TABLE (
    metodopagoid INT,
    tipo VARCHAR(50)
) AS $$
BEGIN
    RETURN QUERY
       SELECT M.metodopagoid AS metodopagoid,
              M.tipo AS tipo
       FROM metodopago M
       WHERE M.metodopagoid = p_metodopagoid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE MetodoDePago
CREATE OR REPLACE PROCEDURE actualizar_metodopago(
    p_metodopagoid INT,
    p_tipo VARCHAR(50)
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE metodopago
    SET tipo = p_tipo
    WHERE metodopagoid = p_metodopagoid;
END;
$$;

-- DELETE MetodoDePago
CREATE OR REPLACE PROCEDURE eliminar_metodopago(
    p_metodopagoid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM metodopago
    WHERE metodopagoid = p_metodopagoid;
END;
$$;

--------------------------------------------------------------------------------
-- CRUD PARA TICKET
--------------------------------------------------------------------------------
-- CREATE Ticket
CREATE OR REPLACE PROCEDURE crear_ticket(
    p_reservid INT,
    p_costototal NUMERIC(10,2),
    p_metododepago INT,
    p_estado VARCHAR(50),
    p_fechadepago DATE
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO ticket (reservid, costototal, metododepago, estado, fechadepago)
    VALUES (p_reservid, p_costototal, p_metododepago, p_estado, p_fechadepago);
END;
$$;

-- READ Ticket
CREATE OR REPLACE FUNCTION obtener_ticket(p_reservid INT)
RETURNS TABLE (
    reservid INT,
    costototal NUMERIC(10,2),
    metododepago INT,
    estado VARCHAR(50),
    fechadepago DATE
) AS $$
BEGIN
    RETURN QUERY
       SELECT T.reservid AS reservid,
              T.costototal AS costototal,
              T.metododepago AS metododepago,
              T.estado AS estado,
              T.fechadepago AS fechadepago
       FROM ticket T
       WHERE T.reservid = p_reservid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE Ticket
CREATE OR REPLACE PROCEDURE actualizar_ticket(
    p_reservid INT,
    p_costototal NUMERIC(10,2),
    p_metododepago INT,
    p_estado VARCHAR(50),
    p_fechadepago DATE
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE ticket
    SET costototal = p_costototal,
        metododepago = p_metododepago,
        estado = p_estado,
        fechadepago = p_fechadepago
    WHERE reservid = p_reservid;
END;
$$;

-- DELETE Ticket
CREATE OR REPLACE PROCEDURE eliminar_ticket(
    p_reservid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    DELETE FROM ticket
    WHERE reservid = p_reservid;
END;
$$;

-- CREATE: Procedimiento para insertar una nueva finca.
CREATE OR REPLACE PROCEDURE crear_finca(
    p_nombre VARCHAR(100),
    p_ubicacion VARCHAR(200),
    p_tarifa NUMERIC(10,2),
    p_usuarioid INT,
    p_descripcion TEXT
)
LANGUAGE plpgsql AS $$
BEGIN
    INSERT INTO finca (nombre, ubicacion, tarifahora, usuarioid, descripcion, activo)
    VALUES (p_nombre, p_ubicacion, p_tarifa, p_usuarioid, p_descripcion, TRUE);
END;
$$;

-- READ: Función para obtener una finca por su ID.
CREATE OR REPLACE FUNCTION obtener_finca(p_fincaid INT)
RETURNS TABLE (
    fincaid INT,
    nombre VARCHAR(100),
    ubicacion VARCHAR(200),
    tarifahora NUMERIC(10,2),
    usuarioid INT,
    descripcion TEXT,
    activo BOOLEAN
) AS $$
BEGIN
    RETURN QUERY
       SELECT F.fincaid AS fincaid,
              F.nombre AS nombre,
              F.ubicacion AS ubicacion,
              F.tarifahora AS tarifahora,
              F.usuarioid AS usuarioid,
              F.descripcion AS descripcion,
              F.activo AS activo
       FROM finca F
       WHERE F.fincaid = p_fincaid;
END;
$$ LANGUAGE plpgsql;

-- UPDATE: Procedimiento para actualizar los datos de una finca.
CREATE OR REPLACE PROCEDURE actualizar_finca(
    p_fincaid INT,
    p_nombre VARCHAR(100),
    p_ubicacion VARCHAR(200),
    p_tarifa NUMERIC(10,2),
    p_usuarioid INT,
    p_descripcion TEXT,
    p_activo BOOLEAN
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE finca
    SET nombre = p_nombre,
        ubicacion = p_ubicacion,
        tarifahora = p_tarifa,
        usuarioid = p_usuarioid,
        descripcion = p_descripcion,
        activo = p_activo
    WHERE fincaid = p_fincaid;
END;
$$;

-- DELETE: Procedimiento para "eliminar" una finca (marcándola como inactiva).
CREATE OR REPLACE PROCEDURE eliminar_finca(
    p_fincaid INT
)
LANGUAGE plpgsql AS $$
BEGIN
    UPDATE finca
    SET activo = FALSE
    WHERE fincaid = p_fincaid;
END;
$$;