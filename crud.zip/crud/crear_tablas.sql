-- Tabla Rol
CREATE TABLE Rol (
    Rol_Id SERIAL PRIMARY KEY,
    nombreRol VARCHAR(100)
);

-- Tabla Usuario
CREATE TABLE Usuario (
    UsuarioID SERIAL PRIMARY KEY,
    Nombre VARCHAR(100),
    Correo VARCHAR(100),
    Contraseña VARCHAR(100),
    IntentosFallidosIngreso INT,
    Activo BOOLEAN,
    Rol_Id INT REFERENCES Rol(Rol_Id)
);

-- Tabla Amenitie
CREATE TABLE Amenitie (
    AmenitieID SERIAL PRIMARY KEY,
    Nombre VARCHAR(100),
    TipoDeAmenitie VARCHAR(100)
);

-- Tabla FINCA
CREATE TABLE FINCA (
    FincaID SERIAL PRIMARY KEY,
    Nombre VARCHAR(100),
    Ubicacion VARCHAR(200),
    TarifaHora NUMERIC(10,2),
    UsuarioId INT REFERENCES Usuario(UsuarioID),
    Descripcion TEXT,
    Activo BOOLEAN
);

-- Tabla Amenitie_FINCA (relación N:M)
CREATE TABLE Amenitie_FINCA (
    FincaID INT REFERENCES FINCA(FincaID),
    AmenitieID INT REFERENCES Amenitie(AmenitieID),
    PRIMARY KEY (FincaID, AmenitieID)
);

-- Tabla Imagen
CREATE TABLE Imagen (
    ImagenID SERIAL PRIMARY KEY,
    FincaID INT REFERENCES FINCA(FincaID),
    urlImagen TEXT
);

-- Tabla Horario
CREATE TABLE Horario (
    HorarioID SERIAL PRIMARY KEY,
    HoraInicio TIME,
    HoraFin TIME,
    Fecha DATE
);

-- Tabla Finca_Horario (relación entre Finca y Horario)
CREATE TABLE Finca_Horario (
    FincaHorarioID SERIAL PRIMARY KEY,
    HorarioID INT REFERENCES Horario(HorarioID),
    FincaID INT REFERENCES FINCA(FincaID)
);

-- Tabla Descuento
CREATE TABLE Descuento (
    descuentoId SERIAL PRIMARY KEY,
    Nombre VARCHAR(100),
    DescuentoPorcentaje NUMERIC(5,2)
);

-- Tabla Temporada
CREATE TABLE Temporada (
    temporadaID SERIAL PRIMARY KEY,
    temporadaNombre VARCHAR(100)
);

-- Tabla TipoDeTemporada
CREATE TABLE TipoDeTemporada (
    IdTipoDeTemporada SERIAL PRIMARY KEY,
    IdTemporada INT REFERENCES Temporada(temporadaID),
    idDescuento INT REFERENCES Descuento(descuentoId)
);

-- Tabla Reserva
CREATE TABLE Reserva (
    ReservID SERIAL PRIMARY KEY,
    FincaHorarioID INT REFERENCES Finca_Horario(FincaHorarioID),
    UsuarioID INT REFERENCES Usuario(UsuarioID),
    TipoDeTemporada INT REFERENCES TipoDeTemporada(IdTipoDeTemporada),
    Activo BOOLEAN,
    Vencimiento DATE
);

-- Tabla Comentario
CREATE TABLE Comentario (
    UsuarioId INT REFERENCES Usuario(UsuarioID),
    FincaID INT REFERENCES FINCA(FincaID),
    ReservId INT REFERENCES Reserva(ReservID),
    Descripcion TEXT,
    PRIMARY KEY (UsuarioId, FincaID, ReservId)
);

-- Tabla MetodoDePago
CREATE TABLE MetodoDePago (
    MetodoDePagoID SERIAL PRIMARY KEY,
    Tipo VARCHAR(50)
);

-- Tabla Ticket
CREATE TABLE Ticket (
    ReservID INT PRIMARY KEY REFERENCES Reserva(ReservID),
    CostoTotal NUMERIC(10,2),
    MetodoDePago INT REFERENCES MetodoDePago(MetodoDePagoID),
    Estado VARCHAR(50),
    FechaDePago DATE
);
